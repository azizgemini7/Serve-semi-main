library paloma.globals;
String myid='';
double longitude=-1;
double latitude=-1;
String currentorder='1';
bool loadvideo=false;